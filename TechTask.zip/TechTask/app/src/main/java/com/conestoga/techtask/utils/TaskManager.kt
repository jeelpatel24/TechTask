// TaskManager.kt
import com.conestoga.techtask.model.Task

object TaskManager {
    private val tasks = mutableListOf<Task>()

    // Add a new task
    fun addTask(task: Task) {
        tasks.add(task)
    }

    // Get all incomplete tasks
    fun getIncompleteTasks(): List<Task> {
        return tasks.filter { !it.isCompleted }
    }

    // Print all task titles
    fun printAllTaskTitles() {
        tasks.map { it.title }.forEach { println(it) }
    }

    // Print incomplete tasks
    fun printIncompleteTasks() {
        val incompleteTasks = getIncompleteTasks()
        if (incompleteTasks.isEmpty()) {
            println("All tasks are completed!")
            return
        }

        println("Incomplete Tasks:")
        incompleteTasks.forEach { task ->
            println("ID: ${task.id}, Title: ${task.title}, Description: ${task.description}")
        }
    }

    // Toggle task completion status by ID
    fun toggleTaskCompletion(taskId: Int) {
        tasks.find { it.id == taskId }?.toggleCompletion()
    }

    // Get all tasks (for demonstration)
    fun getAllTasks(): List<Task> = tasks.toList()
}