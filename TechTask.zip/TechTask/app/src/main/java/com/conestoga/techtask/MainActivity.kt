// MainActivity.kt
package com.conestoga.techtask

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.conestoga.techtask.model.Task


class MainActivity : AppCompatActivity() {
    private lateinit var taskTitleEditText: EditText
    private lateinit var taskDescriptionEditText: EditText
    private lateinit var tasksTextView: TextView
    private var taskIdCounter = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        taskTitleEditText = findViewById(R.id.taskTitleEditText)
        taskDescriptionEditText = findViewById(R.id.taskDescriptionEditText)
        tasksTextView = findViewById(R.id.tasksTextView)

        // Set up button click listeners
        findViewById<Button>(R.id.addTaskButton).setOnClickListener {
            addTask()
        }

        findViewById<Button>(R.id.viewTasksButton).setOnClickListener {
            displayAllTasks()
        }

        findViewById<Button>(R.id.viewIncompleteButton).setOnClickListener {
            displayIncompleteTasks()
        }
    }

    private fun addTask() {
        val title = taskTitleEditText.text.toString().trim()
        val description = taskDescriptionEditText.text.toString().trim()

        if (title.isEmpty()) {
            Toast.makeText(this, "Please enter a task title", Toast.LENGTH_SHORT).show()
            return
        }

        val newTask = Task(
            id = taskIdCounter++,
            title = title,
            description = description
        )

        TaskManager.addTask(newTask)
        Toast.makeText(this, "Task added successfully", Toast.LENGTH_SHORT).show()

        // Clear input fields
        taskTitleEditText.text.clear()
        taskDescriptionEditText.text.clear()


    }

    private fun displayAllTasks() {
        val tasks = TaskManager.getAllTasks()
        if (tasks.isEmpty()) {
            tasksTextView.text = "No tasks available"
            return
        }

        val tasksText = buildString {
            append("All Tasks:\n\n")
            tasks.forEach { task ->
                append("ID: ${task.id}\n")
                append("Title: ${task.title}\n")
                append("Description: ${task.description}\n")
                append("Status: ${if (task.isCompleted) "Completed" else "Incomplete"}\n\n")
            }
        }

        tasksTextView.text = tasksText
    }

    private fun displayIncompleteTasks() {
        val incompleteTasks = TaskManager.getIncompleteTasks()
        if (incompleteTasks.isEmpty()) {
            tasksTextView.text = "All tasks are completed!"
            return
        }

        val tasksText = buildString {
            append("Incomplete Tasks:\n\n")
            incompleteTasks.forEach { task ->
                append("ID: ${task.id}\n")
                append("Title: ${task.title}\n")
                append("Description: ${task.description}\n\n")
            }
        }

        tasksTextView.text = tasksText
    }
}