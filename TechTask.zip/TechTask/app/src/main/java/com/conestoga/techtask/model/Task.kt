// Task.kt
package com.conestoga.techtask.model

data class Task(
    val id: Int,
    val title: String,
    val description: String,
    var isCompleted: Boolean = false
) {
    // Method to toggle completion status
    fun toggleCompletion() {
        isCompleted = !isCompleted
    }
}