# Task Manager Application

## Overview
This is a simple Task Manager Android application that allows users to:
- Add new tasks with titles and descriptions
- View all tasks
- View only incomplete tasks

## Features
1. **Add Task**: Users can add new tasks by entering a title and description.
2. **View All Tasks**: Displays all tasks with their completion status.
3. **View Incomplete Tasks**: Shows only tasks that are not yet completed.

## How to Run
1. **Android Studio Setup**:
    - Install Android Studio from the official website
    - Open the project in Android Studio
    - Sync Gradle files if prompted
    - Connect an Android device or set up an emulator
    - Run the app by clicking the green "Run" button

2. **Using the App**:
    - Enter task title and description in the input fields
    - Click "Add Task" to add a new task
    - Click "View All Tasks" to see all tasks
    - Click "View Incomplete Tasks" to see only incomplete tasks

## Implementation Details
- **Kotlin Classes**:
    - `Task.kt`: Data class representing a task with properties like id, title, description, and completion status.
    - `TaskManager.kt`: Singleton object that manages the list of tasks and provides operations like adding, filtering, and toggling tasks.

- **Android Components**:
    - `MainActivity.kt`: Handles user interactions and displays the UI.
    - `activity_main.xml`: Defines the layout with TextViews, EditTexts, and Buttons.
